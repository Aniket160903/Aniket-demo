# ISG25JFA003_HealthcareAppointmentManagementSystem
This document is a Low-Level Design (LLD) for a Healthcare Appointment Management System. It outlines the technical blueprint, detailing the backend (REST API), frontend (Angular/React), and database design. It covers key modules like User Management, Appointment Scheduling, and Consultation Records.
