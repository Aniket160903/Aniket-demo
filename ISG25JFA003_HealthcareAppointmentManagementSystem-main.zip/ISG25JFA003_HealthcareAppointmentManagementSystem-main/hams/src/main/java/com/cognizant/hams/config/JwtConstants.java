package com.cognizant.hams.config;

public class JwtConstants {
    public static final String SECRET_KEY = "mpJdIyGLq4jhIkAXzaTLIlQJTOBuZOd7dQcLRs08KYg=";
    public static final long EXPIRATION_TIME = 1000*60*60; // 1hr
}