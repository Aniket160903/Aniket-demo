package com.cognizant.hams.dto.request;

public class PrescriptionDTO {
}
