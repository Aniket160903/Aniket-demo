 package com.cognizant.hams.entity; // Or a new dto/enum package

    public enum AppointmentStatus {
        COMPLETED,
        CANCELED,
        PENDING,
        CONFIRMED,
        REJECTED,
    }
