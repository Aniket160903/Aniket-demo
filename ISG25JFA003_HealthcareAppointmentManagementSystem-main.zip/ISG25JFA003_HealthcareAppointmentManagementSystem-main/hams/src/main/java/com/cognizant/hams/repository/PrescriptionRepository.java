package com.cognizant.hams.repository;

public interface PrescriptionRepository {
}
