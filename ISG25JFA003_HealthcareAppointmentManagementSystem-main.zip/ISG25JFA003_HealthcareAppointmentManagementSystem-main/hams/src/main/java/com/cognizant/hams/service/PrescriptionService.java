package com.cognizant.hams.service;

public interface PrescriptionService {
}
