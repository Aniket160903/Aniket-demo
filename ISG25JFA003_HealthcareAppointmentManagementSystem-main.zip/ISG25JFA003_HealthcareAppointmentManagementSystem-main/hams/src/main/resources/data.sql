INSERT INTO roles (role_id, name, description) VALUES
('1', 'ADMIN', 'Administrator role with full access.'),
('2', 'DOCTOR', 'Healthcare professional role.'),
('3', 'PATIENT', 'General user role for patients.');