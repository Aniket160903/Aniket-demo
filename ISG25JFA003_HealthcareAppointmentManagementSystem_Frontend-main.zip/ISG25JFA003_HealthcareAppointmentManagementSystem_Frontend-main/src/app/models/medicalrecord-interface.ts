export interface MedicalRecord {
  date: string;
  type: string;
  notes: string;
}
